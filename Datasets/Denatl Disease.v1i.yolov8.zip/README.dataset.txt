# Denatl Disease > 2025-10-11 6:57pm
https://universe.roboflow.com/ismail-kqbnv/denatl-disease-mtmuf

Provided by a Roboflow user
License: CC BY 4.0

